/* TravelEssentials: NL / EN language switch.
   Dutch is written in the HTML. When English is chosen, every text node and
   label is swapped through the dictionary below, including text that the
   cart and product scripts render later (a MutationObserver catches those).
   Choice is kept in localStorage (te_lang) and can be forced with ?lang=en. */
(() => {
  const KEY = 'te_lang';
  const qs = new URLSearchParams(location.search).get('lang');
  let lang = 'nl';
  try {
    if (qs === 'en' || qs === 'nl') localStorage.setItem(KEY, qs);
    lang = localStorage.getItem(KEY) === 'en' ? 'en' : 'nl';
  } catch (e) { if (qs === 'en') lang = 'en'; }

  /* ---------- dictionary: exact Dutch text -> English ---------- */
  const D = {
    // head
    'TravelEssentials | De gevulde reiskit voor je handbagage': 'TravelEssentials | The ready-filled travel kit for your hand luggage',
    'Doorzichtige reiskit, al gevuld met je essentials en klaar voor de security. Besteld voor 22:00, volgende dag verzonden. Gratis verzending vanaf €50.': 'Clear travel kit, already filled with your essentials and ready for security. Order before 22:00, shipped the next day. Free shipping from €50.',
    'Doorzichtige reiskit, al gevuld en klaar voor je handbagage. Besteld voor 22:00, morgen verzonden. Gratis verzending vanaf €50.': 'Clear travel kit, already filled and ready for your hand luggage. Order before 22:00, shipped tomorrow. Free shipping from €50.',
    // announcement + nav
    'Aankondiging': 'Announcement', 'Vorige melding': 'Previous message', 'Volgende melding': 'Next message',
    'Besteld voor 22:00 uur? Volgende dag verzonden': 'Order before 22:00? Shipped the next day',
    'Gratis verzending vanaf €50': 'Free shipping from €50',
    'Neem 3 kits en betaal €30,95 per kit': 'Take 3 kits and pay €30.95 per kit',
    'Menu openen': 'Open menu', 'Hoofdmenu': 'Main menu', 'Hoe het werkt': 'How it works',
    'Zoeken': 'Search', 'Winkelmand openen': 'Open cart',
    // hero
    'uit 1.200+ reviews': 'from 1,200+ reviews', '4,8/5': '4.8/5',
    'Je reiskit,': 'Your travel kit,', 'al ingepakt': 'already packed',
    'Een doorzichtige toilettas, gevuld met alle verzorging die je onderweg nodig hebt. Gewoon in je handbagage stoppen en vertrekken.': 'A clear toiletry bag, filled with everything you need on the road. Put it in your hand luggage and go.',
    'Kant-en-klaar gevuld, niets meer bij elkaar zoeken': 'Ready-filled, no more gathering bits and pieces',
    'Doorzichtig en handbagage-proof voor de security': 'Clear and hand-luggage-proof for security',
    'Besteld voor 22:00, morgen verzonden': 'Order before 22:00, shipped tomorrow',
    'Kies je kit': 'Choose your kit', 'Vanaf': 'From', '€30,95 per kit': '€30.95 per kit',
    'Gevulde transparante reiskit van TravelEssentials': 'Filled clear travel kit by TravelEssentials',
    'Morgen verzonden': 'Shipped tomorrow', 'Bestel voor 22:00': 'Order before 22:00',
    'Handbagage-proof': 'Hand-luggage-proof', 'Door de security in één blik': 'Through security at a glance',
    // reviews
    'Klantbeoordelingen': 'Customer reviews', 'Uitstekend': 'Excellent',
    '4,8 van 5 sterren': '4.8 out of 5 stars', '4,8 op basis van 1.200+ reviews op': '4.8 based on 1,200+ reviews on',
    '5 sterren': '5 stars', '4 sterren': '4 stars', '✓ Geverifieerd': '✓ Verified',
    'Nooit meer last-minute flesjes kopen': 'No more last-minute bottle shopping',
    'Besteld op dinsdag, donderdag in huis. Ging zo mee in mijn handbagage naar Barcelona.': 'Ordered on Tuesday, arrived Thursday. Went straight into my hand luggage to Barcelona.',
    'Ideaal voor korte citytrips': 'Perfect for short city trips',
    'Alles zit erin en je ziet meteen wat je hebt. Bij de security moest ik niets uitpakken.': 'Everything is in it and you see right away what you have. I did not have to unpack anything at security.',
    'Drie kits voor het hele gezin': 'Three kits for the whole family',
    'Voor iedereen een eigen tas, scheelt echt gedoe in de badkamer op vakantie.': 'A bag for everyone, which really saves hassle in the bathroom on holiday.',
    'Mooi cadeau': 'Lovely gift',
    'Gegeven aan mijn vriend voor zijn eerste zakenreis. Netjes verpakt en snel geleverd.': 'Gave it to my boyfriend for his first business trip. Nicely packed and delivered fast.',
    'Voorbeeldreviews in dit ontwerp. Live komt hier de Trustpilot-widget.': 'Sample reviews in this design. The live site will show the Trustpilot widget here.',
    'Precies wat ik nodig had': 'Exactly what I needed',
    'Alles zat erin, ik heb onderweg niets moeten bijkopen.': 'Everything was in it, I did not have to buy anything on the way.',
    'Snel geleverd': 'Fast delivery',
    'Avond besteld, twee dagen later in de bus. Netjes verpakt.': 'Ordered in the evening, in my mailbox two days later. Nicely packed.',
    'Security in één keer': 'Through security in one go',
    'Tas eruit, door de scanner, klaar. Geen gedoe met zakjes.': 'Bag out, through the scanner, done. No fiddling with little plastic bags.',
    'Mooi als cadeau': 'Great as a gift',
    'Gegeven voor een eerste zakenreis, viel heel goed in de smaak.': 'Given for a first business trip, it went down really well.',
    // strip
    'Kant-en-klaar gevuld': 'Ready-filled', 'Doorzichtige tas': 'Clear bag',
    'Veilig betalen met Bancontact': 'Secure payment with Bancontact',
    // offers
    'Kies je aanbieding': 'Choose your offer',
    'Hoe meer kits, hoe minder je per kit betaalt. Vanaf 2 kits is de verzending gratis.': 'The more kits, the less you pay per kit. Shipping is free from 2 kits.',
    'Eén reiskit': 'One travel kit', 'Twee reiskits': 'Two travel kits', 'Drie reiskits': 'Three travel kits',
    'Klassiek · €34,95 per kit': 'Classic · €34.95 per kit', 'Klassiek': 'Classic',
    '1 gevulde reiskit naar keuze:': '1 filled travel kit of your choice:',
    'Verzendkosten betaal je zelf': 'Shipping costs not included',
    'In winkelmand': 'Add to cart', 'Meest gekozen': 'Most popular', 'Beste voordeel': 'Best value',
    'Voor jullie samen · €32,45 per kit': 'For the two of you · €32.45 per kit',
    'Je bespaart €5': 'You save €5', 'Je bespaart €11,95': 'You save €11.95',
    '2 gevulde reiskits, mix For Her en For Him': '2 filled travel kits, mix For Her and For Him',
    'Gratis verzending': 'Free shipping',
    'Voor het hele gezin · €30,95 per kit': 'For the whole family · €30.95 per kit',
    '3 gevulde reiskits, vrij te combineren': '3 filled travel kits, combine as you like',
    'Voor 22:00 besteld, morgen verzonden': 'Ordered before 22:00, shipped tomorrow',
    'Veilig betalen met Bancontact, iDEAL en kaart': 'Secure payment with Bancontact, iDEAL and card',
    'Eenvoudig retourneren': 'Easy returns', 'Of bekijk de kits apart': 'Or view the kits separately',
    'Bekijk →': 'View →', 'Meest gekozen · 2 kits': 'Most popular · 2 kits', 'Beste voordeel · 3 kits': 'Best value · 3 kits',
    // how it works
    'Zo werkt het': 'How it works', 'Van bestelling tot boarding in drie stappen.': 'From order to boarding in three steps.',
    'Stap 1': 'Step 1', 'Stap 2': 'Step 2', 'Stap 3': 'Step 3',
    'For Her, For Him of Premium. Neem er meer tegelijk en je betaalt minder per kit.': 'For Her, For Him or Premium. Take more at once and you pay less per kit.',
    'Klaar in 1 minuut': 'Done in 1 minute',
    'Bestel voor 22:00 uur en je kit vertrekt de volgende dag, gevuld en klaar voor gebruik.': 'Order before 22:00 and your kit ships the next day, filled and ready to use.',
    'Instappen': 'Board',
    'Tas in je handbagage, rits dicht, vertrekken. Bij de security zie je in één blik wat je bij je hebt.': 'Bag in your hand luggage, zip it up, off you go. At security you see at a glance what you are carrying.',
    // on the road
    'Reiskit van TravelEssentials in een bak bij de security, naast een handtas': 'TravelEssentials kit in a security tray, next to a handbag',
    'Onderweg': 'On the road', 'Uit je tas, in de bak, klaar': 'Out of your bag, into the tray, done',
    'Bij de security hoef je niets uit te pakken of bij elkaar te zoeken. Alles zit al in een doorzichtige tas, dus je legt hem in de bak en loopt door.': 'At security there is nothing to unpack or gather up. Everything is already in a clear bag, so you put it in the tray and walk on.',
    'Doorzichtig': 'Clear', 'Iedereen ziet in één blik wat erin zit.': 'Anyone can see at a glance what is inside.',
    'Reisformaat': 'Travel size', 'Flesjes en tubes klaar voor je handbagage.': 'Bottles and tubes ready for your hand luggage.',
    'Overal mee': 'Take it anywhere', 'Vliegtuig, trein of weekendje weg.': 'Plane, train or a weekend away.',
    'Reiskit op een tafeltje in de trein': 'Travel kit on a train table',
    'Gevulde reiskit op een tafeltje in de trein': 'Filled travel kit on a train table',
    // UGC
    "Klantvideo's": 'Customer videos', 'Klantvideo': 'Customer video',
    'Wat reizigers erover zeggen': 'What travellers say', 'Echte klanten, echte reizen.': 'Real customers, real trips.',
    "Vorige video's": 'Previous videos', "Volgende video's": 'Next videos',
    'Zo ga ik in één keer door de security': 'How I get through security in one go',
    'Door de security zonder iets uit te pakken': 'Through security without unpacking a thing',
    'Mijn handbagage in 10 seconden': 'My hand luggage in 10 seconds',
    'Een kit voor iedereen in het gezin': 'A kit for everyone in the family',
    'Premium kit review na twee weken reizen': 'Premium kit review after two weeks of travel',
    'Twee weken op reis met de Premium kit': 'Two weeks on the road with the Premium kit',
    'Ons duo-pakket voor de citytrip': 'Our duo pack for the city trip',
    'Unboxing: dit zit er allemaal in': 'Unboxing: here is everything inside',
    'Sarah · Antwerpen': 'Sarah · Antwerp', 'Nora · Brussel': 'Nora · Brussels',
    'Hier speelt de klantvideo af.': 'The customer video plays here.',
    'Voeg de mp4 of TikTok-embed toe in de code.': 'Add the mp4 or TikTok embed in the code.',
    // FAQ
    'Veelgestelde vragen': 'Frequently asked questions',
    'Mag de kit mee in mijn handbagage?': 'Can the kit go in my hand luggage?',
    'Ja. De tas is doorzichtig en past in de regels voor vloeistoffen in de handbagage, zodat je hem bij de security in één keer kan laten zien.': 'Yes. The bag is clear and fits the rules for liquids in hand luggage, so you can show it at security in one go.',
    'Wat zit er precies in een kit?': 'What exactly is in a kit?',
    'Elke kit is gevuld met de verzorging die je onderweg dagelijks gebruikt. Op de productpagina van For Her, For Him en Premium zie je de volledige inhoud.': 'Every kit is filled with the care products you use every day on the road. The For Her, For Him and Premium product pages show the full contents.',
    'Wanneer wordt mijn bestelling verzonden?': 'When will my order ship?',
    'Bestel je voor 22:00 uur, dan verzenden we je kit de volgende dag.': 'Order before 22:00 and we ship your kit the next day.',
    'Kan ik For Her en For Him combineren in een bundel?': 'Can I combine For Her and For Him in a bundle?',
    'Ja, bij 2 of 3 kits kies je zelf welke kits je combineert.': 'Yes, with 2 or 3 kits you choose which kits to combine.',
    'Betaal ik verzendkosten?': 'Do I pay for shipping?',
    'Vanaf €50 is de verzending gratis. Met de meeste duo\'s en bundels zit je daar al boven.': 'Shipping is free from €50. With most duos and bundles you are already above that.',
    // final CTA, newsletter, footer
    'Klaar voor je': 'Ready for your', 'volgende reis?': 'next trip?',
    'Kies je kit vandaag nog. Besteld voor 22:00 uur, morgen verzonden en klaar voor je handbagage.': 'Choose your kit today. Order before 22:00, shipped tomorrow and ready for your hand luggage.',
    'Veilig betalen': 'Secure payment',
    'Schrijf je in bij TravelEssentials': 'Sign up for TravelEssentials',
    'E-mailadres': 'Email address', 'Inschrijven': 'Sign up',
    'Hoor als eerste over nieuwe kits en exclusieve acties.': 'Be the first to hear about new kits and exclusive offers.',
    'Bedankt, je bent ingeschreven.': 'Thanks, you are signed up.',
    'Vul een geldig e-mailadres in, bijvoorbeeld naam@email.be.': 'Enter a valid email address, for example name@email.com.',
    'Klantenservice': 'Customer service', 'Verzending': 'Shipping', 'Retourneren': 'Returns',
    'Over ons': 'About us', 'Bestelling volgen': 'Track order', 'Algemene voorwaarden': 'Terms and conditions',
    'Privacybeleid': 'Privacy policy',
    '2 kits · gratis verzending': '2 kits · free shipping', 'Sluiten': 'Close',
    // menu + cart
    'Menu sluiten': 'Close menu', 'Mobiel menu': 'Mobile menu',
    'Bundels & aanbiedingen': 'Bundles & offers', 'Tot €11,95 korting': 'Up to €11.95 off',
    'Winkelmand': 'Cart', 'Winkelmand sluiten': 'Close cart',
    'Voeg er nog een toe': 'Add one more', 'Hoe meer kits, hoe lager de prijs per kit': 'The more kits, the lower the price per kit',
    '+ Voeg toe': '+ Add', 'Subtotaal': 'Subtotal', 'Veilig afrekenen': 'Secure checkout',
    'Doorsturen naar afrekenen…': 'Taking you to checkout…',
    'Je winkelmand is nog leeg.': 'Your cart is empty.', 'Je verzending is gratis': 'Your shipping is free',
    'Aantal': 'Quantity', 'Eén minder': 'One less', 'Eén meer': 'One more',
    // product page
    'Zoek een vraag…': 'Search a question…', 'Zoek een vraag': 'Search a question', 'Wis zoekopdracht': 'Clear search', 'Onderwerpen': 'Topics', 'Bekijk alle vragen': 'See all questions',
    'Aanbieding · Meest gekozen': 'Deal · Most chosen', 'Duo-deal': 'Duo deal', '2× For Her Kit': '2× For Her Kit', 'Voor jou en je reisgenoot · €32,45 per kit': 'For you and your travel buddy · €32.45 per kit', ', volledig gevuld': ', fully filled', 'Pak de deal': 'Get the deal', 'Nu': 'Now',
    'Ons assortiment': 'Our range',
    'Kies een kit voor jezelf, of reis samen met een duo-deal en bespaar €5.': 'Choose a kit for yourself, or travel together with a duo deal and save €5.',
    "Duo's": 'Duos',
    'Twee kits, één prijs. Altijd €5 korting en gratis verzending.': 'Two kits, one price. Always €5 off and free shipping.',
    'Losse kits': 'Single kits',
    'Essentials voor je dagelijkse verzorging, Premium voor wie niets wil vergeten.': 'Essentials for your daily care, Premium for when you do not want to forget a thing.',
    'Duo-deal · Meest gekozen': 'Duo deal · Most chosen',
    'Voor koppels': 'For couples',
    'Voor twee vrienden': 'For two friends',
    'Voor vriendinnen, moeder en dochter': 'For girlfriends, mother and daughter',
    'Her Essentials en His Essentials samen · €32,45 per kit': 'Her Essentials and His Essentials together · €32.45 per kit',
    'Her Premium en His Premium samen · €42,45 per kit': 'Her Premium and His Premium together · €42.45 per kit',
    '2× His Essentials · €32,45 per kit': '2× His Essentials · €32.45 per kit',
    '2× Her Premium · €42,45 per kit': '2× Her Premium · €42.45 per kit',
    'Bekijk': 'View',
    "Met z'n drieën op reis?": 'Travelling as three?',
    '3 Essentials-kits naar keuze voor': '3 Essentials kits of your choice for',
    '. Je bespaart €11,95.': '. You save €11.95.',
    'Essentials of Premium, voor haar of voor hem. Samen op reis? Neem een duo en bespaar €5.': 'Essentials or Premium, for her or for him. Travelling together? Take a duo and save €5.',
    "Welke duo's zijn er?": 'Which duos are there?',
    'The Travel Couple (Her en His Essentials), The Premium Couple (Her en His Premium), His Essentials Duo voor twee vrienden en Her Premium Duo voor vriendinnen of moeder en dochter. The Premium Couple en de Her Premium Duo staan nu in de aanbieding.': 'The Travel Couple (Her and His Essentials), The Premium Couple (Her and His Premium), His Essentials Duo for two friends and Her Premium Duo for girlfriends or mother and daughter. The Premium Couple and the Her Premium Duo are on offer right now.',
    'Wat is het verschil tussen Essentials en Premium?': 'What is the difference between Essentials and Premium?',
    'Op de productpagina van elke kit zie je de volledige inhoud.': 'The product page of each kit shows the full contents.',
    'De uitgebreide reiskit voor haar, voor wie langer weg is of niets wil vergeten.': 'The extended travel kit for her, for longer trips or when you do not want to forget a thing.',
    'De uitgebreide reiskit voor hem, voor wie langer weg is of niets wil vergeten.': 'The extended travel kit for him, for longer trips or when you do not want to forget a thing.',
    'Her Essentials en His Essentials samen. Voor jullie twee, op dezelfde reis.': 'Her Essentials and His Essentials together. For the two of you, on the same trip.',
    'Her Premium en His Premium samen. Onze meest complete set, voor jullie allebei.': 'Her Premium and His Premium together. Our most complete set, for both of you.',
    '2× His Essentials. Voor twee vrienden op reis, elk met een eigen kit.': '2× His Essentials. For two friends on the road, each with their own kit.',
    '2× Her Premium. Voor twee vriendinnen, of moeder en dochter.': '2× Her Premium. For two girlfriends, or mother and daughter.',
    'De doorzichtige reiskit voor haar, gevuld met je dagelijkse verzorging.': 'The clear travel kit for her, filled with your daily care products.',
    'De doorzichtige reiskit voor hem, met alles voor de ochtendroutine.': 'The clear travel kit for him, with everything for the morning routine.',
    'Volledig gevulde kit': 'Fully filled kit',
    'In elke kit': 'In every kit',
    '1 duo · 2 kits': '1 duo · 2 kits',
    'Duo-deal · 2 kits': 'Duo deal · 2 kits',
    '3 Essentials-kits': '3 Essentials kits',
    'Extra': 'Extra',
    '2× Her Premium · €32,48 per kit': '2× Her Premium · €32.48 per kit',
    "Samen op reis, elk een eigen kit. Deze twee duo's staan nu in de aanbieding.": 'Travelling together, each with your own kit. These two duos are on offer right now.',
    'Kies een kit voor jezelf, of reis samen met een duo.': 'Choose a kit for yourself, or travel together with a duo.',
    'Samen op reis? Kies een duo.': 'Travelling together? Choose a duo.',
    'Aanbieding': 'Deal',
    'Duo': 'Duo',
    'Duo · 2 kits': 'Duo · 2 kits',
    'The Premium Couple en de Her Premium Duo staan nu in de aanbieding.': 'The Premium Couple and the Her Premium Duo are on offer right now.',
    'Her Premium en His Premium samen · €29,95 per kit': 'Her Premium and His Premium together · €29.95 per kit', 'Je bespaart €3': 'You save €3',
    "Duo's & aanbiedingen": 'Duos & offers', 'Nu in de aanbieding': 'On offer now', "Duo's vanaf": 'Duos from',
    'Kruimelpad': 'Breadcrumb', 'Reiskits': 'Travel kits', 'Vorige foto': 'Previous photo', 'Volgende foto': 'Next photo',
    '1.200+ reviews': '1,200+ reviews', '4,8': '4.8',
    'Meer kits = lagere prijs per kit': 'More kits = lower price per kit', 'Aantal kits': 'Number of kits',
    'Eenvoudig retour': 'Easy returns', 'Wat zit erin': "What's inside", 'Gebruik op reis': 'Use while travelling',
    'Stop de kit zo in je handbagage. Bij de security haal je hem er in één keer uit: de tas is doorzichtig, dus je hoeft niets apart in te pakken. Op je bestemming hang of zet je hem gewoon in de badkamer.': 'Put the kit straight into your hand luggage. At security you take it out in one go: the bag is clear, so there is nothing to pack separately. At your destination, just hang it up or set it down in the bathroom.',
    'Verzending & retour': 'Shipping & returns',
    'Besteld voor 22:00 uur, dan verzenden we de volgende dag. Vanaf €50 is de verzending gratis. Niet tevreden? Je kan ongeopende kits eenvoudig retourneren.': 'Order before 22:00 and we ship the next day. Shipping is free from €50. Not happy? You can easily return unopened kits.',
    'Alles wat je onderweg elke dag gebruikt, op één plek.': 'Everything you use every day on the road, in one place.',
    'Inhoud ter illustratie in dit ontwerp.': 'Contents shown for illustration in this design.',
    'Waarom een kit?': 'Why a kit?', 'Vergeleken met zelf alles bij elkaar zoeken.': 'Compared with gathering everything yourself.',
    'Onze kit': 'Our kit', 'Zelf inpakken': 'Packing yourself',
    'Klaar in 10 seconden': 'Ready in 10 seconds', 'Doorzichtig voor de security': 'Clear for security',
    'Reisformaat, geen halfvolle flessen': 'Travel size, no half-empty bottles', 'Niets vergeten': 'Nothing forgotten',
    'Gemaakt om': 'Made to', 'mee te reizen': 'travel with you',
    'Inpakken in 10 seconden': 'Packed in 10 seconds',
    'Tas pakken, in je koffer, klaar. Geen lijstjes meer.': 'Grab the bag, into your suitcase, done. No more packing lists.',
    'Alles in één blik': 'Everything at a glance',
    'De doorzichtige tas toont meteen wat je bij je hebt.': 'The clear bag shows straight away what you are carrying.',
    'Compact in je handbagage': 'Compact in your hand luggage',
    'Reisformaat, dus geen ruimte verloren in je koffer.': 'Travel size, so no space lost in your suitcase.',
    'In actie gezien': 'Seen in action', 'Klanten tonen hun kit onderweg.': 'Customers show their kit on the road.',
    'Bekijk ook': 'You may also like',
    'De doorzichtige reiskit voor haar, gevuld met je dagelijkse verzorging. Klaar voor je handbagage.': 'The clear travel kit for her, filled with your daily care products. Ready for your hand luggage.',
    'De doorzichtige reiskit voor hem, met alles voor de ochtendroutine. Tas erin en vertrekken.': 'The clear travel kit for him, with everything for the morning routine. Bag in, and off you go.',
    'De uitgebreide reiskit voor wie langer weg is of niets wil vergeten. Onze meest complete set.': 'The extended travel kit for longer trips or for anyone who wants to forget nothing. Our most complete set.',
    'Populair': 'Popular', 'Meest compleet': 'Most complete',
    'Tandenborstel': 'Toothbrush', 'Tandpasta': 'Toothpaste', 'Douchegel': 'Shower gel', 'Crème': 'Cream',
    'Mondwater': 'Mouthwash', 'Scheermes': 'Razor', 'Kam': 'Comb', 'Gezicht en lichaam': 'Face and body', 'Met rits': 'With zip',
    'Bestel nu en we verzenden': 'Order now and we ship', 'Bestel binnen': 'Order within', 'en we verzenden': 'and we ship',
    'Nog': 'Add', 'tot gratis verzending': 'more for free shipping',
    // contact page
    'Stuur een bericht': 'Send a message', 'Naam': 'Name', 'Bestelnummer': 'Order number', '(optioneel)': '(optional)',
    'Bijvoorbeeld #1042': 'For example #1042', 'Onderwerp': 'Subject', 'Bericht': 'Message', 'Verstuur bericht': 'Send message',
    'Vraag over een bestelling': 'Question about an order', 'Verzending en levering': 'Shipping and delivery',
    'Retour of ruilen': 'Return or exchange', 'Vraag over een kit': 'Question about a kit',
    'Samenwerking of groothandel': 'Partnership or wholesale', 'Iets anders': 'Something else',
    'Vul je naam, een geldig e-mailadres en je bericht in.': 'Please fill in your name, a valid email address and your message.',
    'Je e-mailprogramma opent met je bericht. Verstuur het daar en we nemen zo snel mogelijk contact op.': 'Your email app opens with your message. Send it from there and we will get back to you as soon as we can.',
    'Besteld voor 22:00 uur, volgende dag verzonden.': 'Order before 22:00, shipped the next day.',
    'Misschien staat je antwoord er al tussen.': 'Your answer may already be there.', 'Bekijk de FAQ': 'View the FAQ',
    '14 dagen bedenktijd op ongeopende kits.': '14 day cooling-off period on unopened kits.',
    'Inhoud': 'Contents'
  };

  /* patterns for text with changing numbers or names */
  const R = [
    [/^(.*), foto (\d+)$/, '$1, photo $2'], [/^Foto (\d+)$/, 'Photo $1'], [/^Ga naar (\d+)$/, 'Go to $1'],
    [/^Verwijder (.+)$/, 'Remove $1'], [/^(.+) onderweg$/, '$1 on the road'],
    [/^Vanaf (€[\d,]+) per kit$/, 'From $1 per kit'], [/^(€[\d,]+) · Duo-deal$/, '$1 · Duo deal'], [/^Je bespaart (€[\d,]+)$/, 'You save $1'],
    [/^(\d+)u (\d+)m$/, '$1h $2m'],
    [/^(\d) kits? · (Meest gekozen|Beste voordeel)$/, (m, n, t) => n + ' kits · ' + D[t]]
  ];
  const DAYS = { maandag: 'Monday', dinsdag: 'Tuesday', woensdag: 'Wednesday', donderdag: 'Thursday', vrijdag: 'Friday', zaterdag: 'Saturday', zondag: 'Sunday' };
  const MONTHS = { januari: 'January', februari: 'February', maart: 'March', april: 'April', mei: 'May', juni: 'June', juli: 'July', augustus: 'August', september: 'September', oktober: 'October', november: 'November', december: 'December' };

  const tr = raw => {
    const s = raw.replace(/\s+/g, ' ').trim();
    if (!s) return null;
    let out = D[s];
    if (out === undefined) {
      for (const [re, to] of R) if (re.test(s)) { out = s.replace(re, to); break; }
    }
    if (out === undefined) {
      const day = s.match(/^(\w+) (\d+) (\w+)$/);
      if (day && DAYS[day[1]] && MONTHS[day[3]]) out = `${DAYS[day[1]]} ${day[2]} ${MONTHS[day[3]]}`;
    }
    if (out === undefined && /€\d+,\d{2}/.test(s)) out = s;   // price only: fix the decimal comma below
    if (out === undefined) return null;
    out = out.replace(/€(\d+),(\d{2})/g, '€$1.$2');
    if (out === s) return null;
    const lead = raw.match(/^\s*/)[0], tail = raw.match(/\s*$/)[0];
    return lead + out + tail;
  };

  const ATTRS = ['alt', 'aria-label', 'placeholder', 'title'];
  const walk = root => {
    if (root.nodeType === 3) {
      const p = root.parentNode;
      if (p && /^(SCRIPT|STYLE)$/.test(p.nodeName)) return;
      if (p && p.closest && p.closest('.i18n-nl,.i18n-en,[data-noi18n]')) return;
      const t = tr(root.nodeValue); if (t !== null) root.nodeValue = t;
      return;
    }
    if (root.nodeType !== 1 || /^(SCRIPT|STYLE)$/.test(root.nodeName)) return;
    const els = [root, ...root.querySelectorAll('*')];
    for (const el of els) for (const a of ATTRS) {
      const v = el.getAttribute(a); if (v) { const t = tr(v); if (t !== null) el.setAttribute(a, t); }
    }
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n; const list = [];
    while ((n = tw.nextNode())) list.push(n);
    list.forEach(walk);
  };

  /* ---------- the switch itself ---------- */
  const setLang = l => {
    try { localStorage.setItem(KEY, l); } catch (e) {}
    const u = new URL(location.href); u.searchParams.delete('lang');
    location.replace(u.href);
  };
  const makeSwitch = cls => {
    const w = document.createElement('div');
    w.className = 'lang ' + cls;
    w.setAttribute('role', 'group');
    w.setAttribute('aria-label', lang === 'en' ? 'Language' : 'Taal');
    w.innerHTML = ['nl', 'en'].map(l => `<button type="button" data-lang="${l}" aria-pressed="${l === lang}" lang="${l}">${l.toUpperCase()}</button>`).join('');
    w.addEventListener('click', e => { const b = e.target.closest('[data-lang]'); if (b && b.dataset.lang !== lang) setLang(b.dataset.lang); });
    return w;
  };
  const icons = document.querySelector('.nav .icons');
  if (icons) icons.prepend(makeSwitch('lang--nav'));
  const menuBody = document.querySelector('#menu .panel__body');
  if (menuBody) menuBody.append(makeSwitch('lang--menu'));

  window.TE_LANG = lang;
  if (lang !== 'en') return;

  const H = document.documentElement;
  H.lang = 'en';
  const md = document.querySelector('meta[name="description"]');
  if (md) { const t = H.dataset.descEn || tr(md.content); if (t) md.content = t; }
  walk(document.body);
  const tt = H.dataset.titleEn || tr(document.title); if (tt) document.title = tt;

  new MutationObserver(muts => {
    for (const m of muts) {
      if (m.type === 'characterData') walk(m.target);
      else if (m.type === 'attributes') { const v = m.target.getAttribute(m.attributeName); const t = v && tr(v); if (t) m.target.setAttribute(m.attributeName, t); }
      else m.addedNodes.forEach(walk);
    }
  }).observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
})();
