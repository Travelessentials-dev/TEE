/* TravelEssentials: shared behaviour for every page */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const euro = c => '€' + (c / 100).toFixed(2).replace('.', ',');
  const FREE_SHIP = 5000;

  /* ---------- announcement ---------- */
  const annMsg = $('#annMsg');
  if (annMsg) {
    const msgs = [
      'Besteld voor 22:00 uur? Volgende dag verzonden',
      'Gratis verzending vanaf €50',
      'Neem 3 kits en betaal €30,95 per kit'
    ];
    let ai = 0;
    const show = d => { ai = (ai + d + msgs.length) % msgs.length; annMsg.textContent = msgs[ai]; };
    $('#annPrev').onclick = () => show(-1);
    $('#annNext').onclick = () => show(1);
    const timer = setInterval(() => show(1), 5000);
    $('.announce').addEventListener('pointerenter', () => clearInterval(timer));
  }

  /* ---------- overlays (menu + cart) ---------- */
  const scrim = $('#scrim');
  let openPanel = null, lastFocus = null;
  const open = panel => {
    if (openPanel) close();
    lastFocus = document.activeElement;
    openPanel = panel;
    panel.classList.add('open'); scrim.classList.add('open');
    panel.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('locked');
    window.__lenis && window.__lenis.stop();
    setTimeout(() => (panel.querySelector('[data-close]') || panel).focus(), 50);
  };
  const close = () => {
    if (!openPanel) return;
    openPanel.classList.remove('open'); scrim.classList.remove('open');
    openPanel.setAttribute('aria-hidden', 'true');
    openPanel = null;
    document.documentElement.classList.remove('locked');
    window.__lenis && window.__lenis.start();
    lastFocus && lastFocus.focus();
  };
  scrim && scrim.addEventListener('click', close);
  addEventListener('keydown', e => { if (e.key === 'Escape') { close(); closeModal(); } });
  $$('[data-close]').forEach(b => b.addEventListener('click', close));
  const menu = $('#menu');
  $$('.burger').forEach(b => b.addEventListener('click', () => open(menu)));
  menu && $$('a', menu).forEach(a => a.addEventListener('click', close));

  /* ---------- cart ---------- */
  const KEY = 'te_cart_v1';
  let cart = [];
  try { cart = JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { cart = []; }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(cart)); } catch (e) {} };
  const drawer = $('#cart');

  const render = () => {
    const count = cart.reduce((n, i) => n + i.qty, 0);
    const total = cart.reduce((n, i) => n + i.qty * i.price, 0);
    $$('.bag__n').forEach(b => { b.textContent = count; b.classList.toggle('empty', !count); });
    if (!drawer) return;
    $('#cartCount').textContent = count ? '(' + count + ')' : '';
    const left = FREE_SHIP - total;
    $('#shipMsg').innerHTML = !total ? 'Gratis verzending vanaf €50'
      : left > 0 ? 'Nog <b>' + euro(left) + '</b> tot gratis verzending' : '<b>Je verzending is gratis</b>';
    $('#shipBar').style.setProperty('--w', Math.min(1, total / FREE_SHIP));
    $('#cartItems').innerHTML = cart.length ? cart.map((i, idx) => `
      <li class="ci">
        <img src="${i.img}" alt="">
        <div class="ci__info">
          <p class="ci__name">${i.name}</p>
          ${i.variant ? `<p class="ci__var">${i.variant}</p>` : ''}
          <div class="ci__row">
            <div class="qty" role="group" aria-label="Aantal">
              <button data-q="-1" data-i="${idx}" aria-label="Eén minder">−</button>
              <span>${i.qty}</span>
              <button data-q="1" data-i="${idx}" aria-label="Eén meer">+</button>
            </div>
            <b>${euro(i.qty * i.price)}</b>
          </div>
        </div>
        <button class="ci__rm" data-rm="${idx}" aria-label="Verwijder ${i.name}">×</button>
      </li>`).join('')
      : '<li class="cart__empty"><p>Je winkelmand is nog leeg.</p><a href="index.html#aanbod" class="btn btn--dark">Kies je kit</a></li>';
    $('#cartTotal').textContent = euro(total);
    $('#cartFoot').hidden = !cart.length;
    $('#cartUpsell').hidden = !cart.length || count >= 3;
  };

  const add = item => {
    const hit = cart.find(i => i.id === item.id && i.variant === item.variant);
    hit ? hit.qty += item.qty || 1 : cart.push({ ...item, qty: item.qty || 1 });
    save(); render();
    $$('.bag__n').forEach(b => { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); });
    drawer ? open(drawer) : null;
  };
  window.TE = { add, euro, open, close };

  if (drawer) {
    drawer.addEventListener('click', e => {
      const q = e.target.closest('[data-q]'), rm = e.target.closest('[data-rm]');
      if (q) { const it = cart[+q.dataset.i]; it.qty += +q.dataset.q; if (it.qty < 1) cart.splice(+q.dataset.i, 1); }
      if (rm) cart.splice(+rm.dataset.rm, 1);
      if (q || rm) { save(); render(); }
    });
    $('#cartUpsellBtn').addEventListener('click', () => {
      const base = cart[cart.length - 1];
      add({ ...base, qty: 1 });
    });
    $('#checkout').addEventListener('click', () => {
      $('#checkout').textContent = 'Doorsturen naar afrekenen…';
      setTimeout(() => { $('#checkout').textContent = 'Veilig afrekenen'; }, 1800);
    });
  }
  $$('.js-cart').forEach(b => b.addEventListener('click', e => { e.preventDefault(); open(drawer); }));
  $$('[data-add]').forEach(b => b.addEventListener('click', () => add({
    id: b.dataset.add, name: b.dataset.name, variant: b.dataset.variant || '',
    price: +b.dataset.price, img: b.dataset.img
  })));
  render();

  /* ---------- rails with arrow buttons ---------- */
  $$('[data-rail]').forEach(rail => {
    const id = rail.id, gap = 12;
    const step = () => (rail.firstElementChild.offsetWidth + gap);
    $$(`[data-rail-prev="${id}"]`).forEach(b => b.onclick = () => rail.scrollBy({ left: -step(), behavior: 'smooth' }));
    $$(`[data-rail-next="${id}"]`).forEach(b => b.onclick = () => rail.scrollBy({ left: step(), behavior: 'smooth' }));
    const dots = $(`[data-dots="${id}"]`);
    if (dots) {
      const n = rail.children.length;
      dots.innerHTML = Array.from({ length: n }, (_, i) => `<button aria-label="Ga naar ${i + 1}" data-i="${i}"></button>`).join('');
      dots.onclick = e => { const b = e.target.closest('button'); if (b) rail.scrollTo({ left: +b.dataset.i * rail.clientWidth, behavior: 'smooth' }); };
      const sync = () => {
        const i = Math.round(rail.scrollLeft / Math.max(1, (rail.scrollWidth - rail.clientWidth)) * (n - 1));
        $$('button', dots).forEach((d, k) => d.classList.toggle('on', k === i));
      };
      rail.addEventListener('scroll', sync, { passive: true }); sync();
    }
  });

  /* ---------- video modal ---------- */
  const modal = $('#modal');
  function closeModal() { modal && modal.classList.remove('open'); }
  if (modal) {
    $$('[data-video]').forEach(c => c.onclick = () => { modal.classList.add('open'); $('#modalClose').focus(); });
    $('#modalClose').onclick = closeModal;
    modal.onclick = e => { if (e.target === modal) closeModal(); };
  }

  /* ---------- sticky buy bar ---------- */
  const buybar = $('#buybar');
  if (buybar) {
    const after = $('[data-buybar-after]'), hides = $$('[data-buybar-hide]');
    const vis = new Map();
    const upd = () => {
      const pastStart = after && vis.get(after) === false && after.getBoundingClientRect().top < 0;
      const hidden = hides.some(h => vis.get(h));
      buybar.classList.toggle('show', !!pastStart && !hidden);
    };
    const bo = new IntersectionObserver(es => { es.forEach(e => vis.set(e.target, e.isIntersecting)); upd(); });
    after && bo.observe(after); hides.forEach(h => bo.observe(h));
    addEventListener('scroll', upd, { passive: true });
  }

  /* ---------- newsletter ---------- */
  const sub = $('#subForm');
  sub && sub.addEventListener('submit', e => {
    e.preventDefault();
    const v = $('#email').value.trim();
    $('#subMsg').textContent = /^\S+@\S+\.\S+$/.test(v)
      ? 'Bedankt, je bent ingeschreven.'
      : 'Vul een geldig e-mailadres in, bijvoorbeeld naam@email.be.';
  });

  /* ---------- motion ---------- */
  requestAnimationFrame(() => document.body.classList.add('is-loaded'));
  $$('[data-stagger]').forEach(g => {
    $$(':scope > [data-reveal]', g).forEach((el, i) => {
      if (!el.style.getPropertyValue('--d')) el.style.setProperty('--d', (i * 0.09 + (+g.dataset.stagger || 0)) + 's');
    });
  });
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    (e.target._clip || e.target).classList.add('is-in'); io.unobserve(e.target);
  }), { rootMargin: '0px 0px -6% 0px', threshold: 0.08 });
  $$('[data-reveal]').forEach(el => io.observe(el));
  // a clipped element has no visible area, so watch a stand-in on its parent
  $$('[data-clip]').forEach(el => {
    const w = document.createElement('div'); w.style.cssText = 'position:absolute;inset:0;pointer-events:none';
    const host = el.parentElement; if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
    w._clip = el; host.appendChild(w); io.observe(w);
  });

  let lenis = null;
  // smooth wheel scrolling on desktop only; phones keep native touch scrolling
  if (!reduce && window.Lenis && matchMedia('(pointer: fine)').matches) {
    lenis = new Lenis({ duration: 1.15, easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)), smoothWheel: true });
    window.__lenis = lenis;
    const raf = t => { lenis.raf(t); requestAnimationFrame(raf); };
    requestAnimationFrame(raf);
  }
  $$('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if (id.length < 2 || !$(id)) return;
    e.preventDefault();
    lenis ? lenis.scrollTo(id, { offset: -70 }) : $(id).scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
  }));

  const prog = $('.progress');
  const par = $$('[data-parallax]');
  const tl = $('#timeline');
  const tsteps = tl ? $$('.tstep', tl) : [];
  let ticking = false;
  const onScroll = () => {
    ticking = false;
    const h = document.documentElement.scrollHeight - innerHeight;
    prog && prog.style.setProperty('--sp', h > 0 ? scrollY / h : 0);
    $('.nav') && $('.nav').classList.toggle('scrolled', scrollY > 10);
    if (reduce) { tl && tl.style.setProperty('--p', 1); tsteps.forEach(s => s.classList.add('is-active')); return; }
    par.forEach(img => {
      const r = img.parentElement.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) return;
      const c = (r.top + r.height / 2 - innerHeight / 2) / innerHeight;
      img.style.translate = '0 ' + (c * -100 * parseFloat(img.dataset.parallax) - 6) + '%';
    });
    if (tl) {
      const r = tl.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, (innerHeight * 0.75 - r.top) / (r.height * 0.9)));
      tl.style.setProperty('--p', p);
      tsteps.forEach((s, i) => s.classList.toggle('is-active', p >= i / (tsteps.length - 1) - 0.02));
    }
  };
  const req = () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } };
  lenis ? lenis.on('scroll', req) : addEventListener('scroll', req, { passive: true });
  addEventListener('resize', req); onScroll();
})();

/* ---------- Trustpilot ----------
   Vul je Business Unit ID in (Trustpilot Business > Integraties > TrustBox).
   Leeg = de site toont gewone links naar Trustpilot, zonder sterren of cijfers.
   De template-ID's kan je vervangen door de TrustBox die je in Trustpilot kiest. */
(() => {
  const TP = { id: '', domain: 'travelessentials.shop', micro: '5419b6ffb0d04a076446a9af', list: '53aa8912dec7e10d38f59f36' };
  if (!TP.id) return;
  const en = document.documentElement.lang === 'en';
  document.querySelectorAll('[data-tp]').forEach(el => {
    const t = el.dataset.tp, w = document.createElement('div');
    w.className = 'trustpilot-widget';
    Object.assign(w.dataset, { locale: en ? 'en-GB' : 'nl-NL', templateId: TP[t], businessunitId: TP.id, styleHeight: t === 'micro' ? '24px' : '240px', styleWidth: '100%', theme: 'light' });
    w.innerHTML = `<a href="https://nl.trustpilot.com/review/${TP.domain}" target="_blank" rel="noopener">Trustpilot</a>`;
    el.replaceChildren(w); el.classList.add('tp-live');
  });
  const s = document.createElement('script');
  s.src = 'https://widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js'; s.async = true;
  document.head.appendChild(s);
})();
